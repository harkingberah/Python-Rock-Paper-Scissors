import random
print("let's play rock,paper scissors. \nComputer picks first! ")
comp_score=0
user_score=0
ready=input("Are you ready to play? ").lower().strip()
while ready.startswith("y"):
    r_p_s=[ "Rock", "Paper", "Scissors"]
    comp_choice=random.choice(r_p_s).lower()
    user_choice=input("pick between rock, paper, scissors: ").lower().strip()
    if user_choice!=comp_choice:
        if user_choice =="rock" and comp_choice=="scissors":
            print(f"\nYour choice is: {user_choice}\n\nComputer's choice is: {comp_choice}\n\nRock crushes scissors.\n\nYou win")
            user_score=user_score+1
        elif comp_choice =="rock" and user_choice=="scissors":
            print(f"\nYour choice is: {user_choice}\n\nComputer's choice is: {comp_choice}\n\nRock crushes scissors.\n\nComputer win")
            comp_score=comp_score+1
        elif user_choice =="scissors" and comp_choice=="paper":
            print(f"\nYour choice is: {user_choice}\n\nComputer's choice is: {comp_choice}\n\nScissors cuts paper.\nYou win")
            user_score=user_score+1
        elif comp_choice =="scissors" and user_choice=="paper":
            print(f"\nYour choice is: {user_choice}\n\nComputer's choice is: {comp_choice}\n\nScissors cuts paper.\n\nComputer win")
            comp_score=comp_score+1
        elif user_choice =="paper" and comp_choice=="rock":
            print(f"\nYour choice is: {user_choice}\n\nComputer's choice is: {comp_choice}\n\nPaper covers rock.\n\nYou win")
            user_score=user_score+1
        elif comp_choice =="paper" and user_choice=="rock":
            print(f"\nYour choice is: {user_choice}\n\nComputer's choice is: {comp_choice}\n\nPaper covers rock.\n\nComputer win")
            comp_score=comp_score+1
    else:
        print("it's a tie")
    ready=input("Do you still want to play? ").lower().strip()
    if ready.startswith("y")==False:
            if user_score!=comp_score:
                if user_score>comp_score:
                     print(f"\nYou win\nYour score is: {user_score} \nComputer's Score is: {comp_score}")
                     break
                else:
                     print(f"\nComputer wins\nYour score is: {user_score} \nComputer's Score is: {comp_score} ")
                     break
            else:
                print(f"\nit's a tie.\n\nYour score is: {user_score} \nComputer's Score is: {comp_score} ")
print("bye!!!")